import UIKit

var str = "Hello, playground"
var str2 = "Goodbye"
var age = 38
var bignum = 8_000_000
var multiline = """
James \
PhD Researcher \
Keele University
"""
var pi = 3.142
var awesome = true
var result = 35
var score = "Your score was \(result)"

let test = "Apple" //let is constant and cannot be changed


let one = "Hello"

//Overiding type inference:
let year: Int = 1984 //the specification of INT overrides Xcodes automatic inference
